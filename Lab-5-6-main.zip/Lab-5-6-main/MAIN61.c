#include <stdio.h>
int main()
{
    int n,p;
    printf("Enter the number of terms: ");
    scanf("%d",&n);

    int a[n];
    for(int i = 0;i<n;i++)
    {
        printf("Enter term[%d]: ",i);
        scanf("%d",&a[i]);
    }

    for(int i = 0;i<n;i++)
    {
        for(int j = i+1;j<n;j++)
        {
            if(a[j] < a[i])
            {
                p = a[i];
                a[i] = a[j];
                a[j] = p;
            }
        }
    }

    printf("Sorted Array :\n");
    for(int i = 0;i<n;i++)
    {
            printf("%d ",a[i]);
    }
}