#include <stdio.h>
int main()
{
    char c;
    printf("Enter your character:");
    scanf("%c",&c);
    printf("ASCII value is %d.",c);
}
