#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    FILE *fp;
    char ch;
    fp = fopen("uk.txt", "w");
    if (fp == NULL) {
        printf("File opening failed\n");
        return 1;
    }
    printf("Enter the strings to write in the file (end with Ctrl+Z+enter): ");
    while ((ch = getchar()) != EOF) {
        fputc(ch, fp);
    }
    fclose(fp);

    fp = fopen("uk.txt", "r");
    if (fp == NULL) {
        printf("The opening of file failed\n");
        return 1;
    }

    int count = 0;
    while ((ch = fgetc(fp)) != EOF) {
        if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
            ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
            count++;
        }
    }
    fclose(fp);
    
    printf("The number of vowels in the file = %d\n", count);

    return 0;
}
