#include<stdio.h>
int main()
{   int n;
    printf("enter no of number of elements in the array"); 
    scanf("%d", &n);
    int a[n], b[n];
    printf("Enter elements of array a");
    for(int i=0; i<n; i++)
    {
        scanf("%d", &a[i]);
    }
    for(int i=0;i<n;i++)
    {
        b[i]=a[n-i-1];
        printf("%d  ", b[i]);
    }

}