#include<stdio.h>
#include <string.h>
int main()
{
    char c[100];
    char *p;
    int count=0;
    
    printf("Enter a string: ");
    gets(c);
    
    p = &c;
    
    while (*p != '\0'){
    if (*p != ' '){
            count++;
        
    }
    p++;
    }
    printf("the string length without space is %d\n", count);
    printf("Size with space: %d",strlen(c));

}