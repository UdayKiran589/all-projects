#include<stdio.h>
#include<string.h>
int main()
{
    int count=0;
    char c[200];
    char *p=c;
 
    printf("enter the word :");
    gets(c);
    int n=strlen(c);
    while(*p !='\0')
    {
        if(*p=='a'||*p=='e'||*p=='i'||*p=='o'||*p=='u')
        {
            count++;
        }
        p++;
    }
    printf("the no of vowels in the word are =%d ",count);
}