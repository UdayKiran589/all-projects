#include<stdio.h>
#include<string.h>
int main()
{
    int count=0;
    char c[10000];
    char *p=c;
    printf("enter the statement :");
    gets(c);
    for(int i=0;i<strlen(c);i++){

        if(c[i]==' ')
        {
            count++;
        }
    }
    printf("the number of words in the statements =%d ",count+1);

}