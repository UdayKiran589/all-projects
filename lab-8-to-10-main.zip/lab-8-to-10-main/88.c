#include<stdio.h>
int main()
{
    int n;
    printf("Enter number of terms: ");
    scanf("%d",&n);
  int a[n],b[n];
  //int *p=a;
  printf("Enter the elements of the array: ");
  for(int i=0;i<n;i++)
  {
    scanf("%d",a+i);
  }
  for(int i=0;i<n;i++)
  {
    b[i]= *(a+i);
  }
  for(int i=0;i<n;i++)
  {
    printf("%d ",b[i]);
  }
}