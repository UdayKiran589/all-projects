#include<stdio.h>
#include<string.h>
struct employ{
    char name[20];
    int number,salary;
}employee[100];
int main()
{
    struct employ *ptr;
    ptr=employee;
    int n;
    printf("enter the number of employees you want to read details at most 100 ");
    scanf("%d",&n);
    getchar();
    for(int i=0;i<n;i++)
    {
        printf("enter the na  zme of employee :\n");
        scanf("%s",ptr->name);
        printf("enter the number of employee :\n");
        scanf("%d",&ptr->number);
        printf("enter the salary of employee:\n");
        scanf("%d",&ptr->salary);
        ptr++;
    }
    ptr=employee;
    printf("the employ details are :\n");
    for(int i=0;i<n;i++)
    {
        printf("\nname of the employee:%s\n",ptr->name);
        printf("the number of the employee is :%d\n",ptr->number);
        printf("the salary of the employee is :%d\n",ptr->salary);
        ptr++;
    }
    return(0);
}