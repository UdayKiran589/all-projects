#include<stdio.h>
#include<string.h>
int main()
{
    char c[100], s[100];
    char *p;
    p=c;
    printf("Enter the strings: ");
    gets(c);
    int n = strlen(c);
    for(int i=0;i<n;i++)
    {
        s[i]=*(p+n-1-i);
    }
    printf("%s",s);
return 0;
}