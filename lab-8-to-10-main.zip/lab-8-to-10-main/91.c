#include<stdio.h>
int main()
{
    int n,a,b;
    int *p=&n;
    printf("Enter a number: ");
    scanf("%d",&n);
    a=*p * *p;
    b=*p * *p * *p;
    printf("Cube of the number is: %d\n",b);
    printf("square of the number is: %d\n",a);

}